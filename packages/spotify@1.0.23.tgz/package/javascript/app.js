// 汉化：抖音 小白科技杂物社 · BiliBili 小白151 · GitHub JackieZ123430
// https://github.com/JackieZ123430/hexlay-spotify-cn
'use strict';
/**
 * Spotify - native BMW iDrive 7 (MGU) Spotify Connect library & playlist browser.
 *
 * Operational Rules:
 *   1. Default Mode: Starts in Online Mode by default.
 *   2. Network Safeguard: In Online Mode, verifies active internet connectivity to Spotify.
 *      If offline, app is disabled with a high-contrast "No Internet Connection" lock screen.
 *   3. Connection Requirement: In Online Mode, requires authenticated personal account.
 *      Gates the player until paired; defaults to Connect tab on first launch.
 *   4. Real Cloud Pairing (No 127.0.0.1): Uses a real cloud pairing relay so any phone on
 *      4G, 5G, or Wi-Fi can scan the QR code and pair directly with Spotify OAuth.
 */
const mgu = require('./kit/mgu');
const { withAlpha } = require('./kit/canvas');
const G = require('./kit/gauges');
const { t: translate } = require('./kit/i18n');

const MEDIA = { literal: true };
const MEDIA_BOLD = { literal: true, font: 'bold' };
function message(key, values) {
    return translate(key).replace(/\{(\w+)\}/g, (_, name) => String(values[name]));
}
const { SpotifyClient } = require('./api');
const { CloudPairManager } = require('./cloud_pair');
const { AlbumArtManager, ART_IMG_ID } = require('./art');
const qrcodegen = require('./kit/qrcodegen');

const W = 1600, H = 520;
const PAGES = ['Playlists', 'Liked Songs', 'Now Playing', 'Connect'];

/*
 * Sizes on this display (kit/runtime/panel.js): k = 1.2 on a 12.3" display, 1.44 on a 10.25" one, so rows,
 * buttons and text come out the same size in millimetres on both (as CarPlay sizes its own). sz(cv, n): n at
 * the reference size (k = 1), rounded.
 */
const kOf = (cv) => (cv.ui && cv.ui.k) || 1.44;
const sz = (cv, n) => Math.round(n * kOf(cv));
/** List metrics: song rows (step: one row to the next; h: drawn), playlist rows, the dock at the bottom. */
function metrics(cv) {
    const ex = cv.extra || 0, dockH = sz(cv, 56);
    const dockY = 512 + ex - dockH;
    const songStep = sz(cv, 44), plStep = sz(cv, 52);
    return {
        dockH, dockY,
        panelH: dockY - 6 - 44,                 // the panels over the dock
        songStep, songH: songStep - 6, plStep, plH: plStep - 8,
        listTop: 98, listBottom: dockY - 14,     // where rows go inside a panel over the dock
        title: sz(cv, 16), meta: sz(cv, 13.5), num: sz(cv, 12.5),
    };
}

// Format milliseconds as MM:SS
function fmtTime(ms) {
    if (!ms || ms < 0) return '0:00';
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const rem = s % 60;
    return m + ':' + (rem < 10 ? '0' : '') + rem;
}

// String truncation with clean ellipsis
function trunc(str, maxLen) {
    if (!str || typeof str !== 'string') return '';
    return str.length > maxLen ? str.slice(0, maxLen - 1) + '..' : str;
}

// Sleek iDrive vertical scrollbar
function drawScrollbar(cv, t, x, y, h, total, visibleCount, scrollOffset, onScrollUp, onScrollDown) {
    if (total <= visibleCount) return;
    const barW = 5;
    // Track background
    cv.roundRect(x, y, barW, h, 2.5, withAlpha(t.panelEdge, 0.4));
    // Thumb calculation
    const maxScroll = Math.max(1, total - visibleCount);
    const thumbH = Math.max(30, Math.round((visibleCount / total) * h));
    const travel = h - thumbH;
    const thumbY = y + Math.round((Math.min(scrollOffset, maxScroll) / maxScroll) * travel);
    // Thumb fill
    cv.roundRect(x, thumbY, barW, thumbH, 2.5, withAlpha(t.accent, 0.7));

    // Touch targets: tapping upper half scrolls up, lower half scrolls down
    if (onScrollUp) {
        cv.target(x - 12, y, 30, Math.floor(h / 2), onScrollUp, 'sb_up_' + x, 8);
    }
    if (onScrollDown) {
        cv.target(x - 12, y + Math.floor(h / 2), 30, Math.ceil(h / 2), onScrollDown, 'sb_down_' + x, 8);
    }
}

// Mini animated equalizer icon for list rows (4 bars)
function drawMiniEqualizer(cv, cx, cy, col, isPlaying, seed) {
    const bars = 4;
    const barW = 3.5;
    const gap = 2.5;
    const totalW = bars * barW + (bars - 1) * gap;
    const startX = cx - totalW / 2;
    for (let i = 0; i < bars; i++) {
        let h;
        if (isPlaying) {
            const phase = seed * 3.2 + i * 1.8;
            h = Math.round(Math.abs(Math.sin(phase)) * 14 + 6);
        } else {
            h = [8, 14, 18, 10][i];
        }
        const bx = startX + i * (barW + gap);
        cv.roundRect(bx, cy - h / 2, barW, h, 1.5, col);
    }
}

// Helper to draw anti-aliased triangles across Recorder and Canvas
function drawTriangle(cv, p0, p1, p2, col) {
    if (cv.triangle) {
        cv.triangle([p0, p1, p2], col);
    } else {
        cv.quad([p0, p1, p2, p2], col);
    }
}

// Vector transport icon drawing helpers
function drawPlayIcon(cv, cx, cy, sz, col) {
    const hw = sz * 0.46, hh = sz * 0.52;
    drawTriangle(cv,
        [cx - hw * 0.7, cy - hh],
        [cx + hw * 1.15, cy],
        [cx - hw * 0.7, cy + hh],
        col
    );
}

function drawPauseIcon(cv, cx, cy, sz, col) {
    const barW = Math.max(3, Math.round(sz * 0.26));
    const barH = Math.round(sz * 0.95);
    const gap = Math.max(3, Math.round(sz * 0.28));
    cv.roundRect(cx - gap / 2 - barW, cy - barH / 2, barW, barH, Math.min(barW / 2, 2), col);
    cv.roundRect(cx + gap / 2, cy - barH / 2, barW, barH, Math.min(barW / 2, 2), col);
}

function drawNextIcon(cv, cx, cy, sz, col) {
    const tw = sz * 0.52, th = sz * 0.46;
    const barW = Math.max(3, Math.round(sz * 0.18));
    const gap = Math.max(3, Math.round(sz * 0.14));
    const totalW = tw + gap + barW;
    const left = cx - totalW / 2;
    drawTriangle(cv,
        [left, cy - th],
        [left + tw, cy],
        [left, cy + th],
        col
    );
    cv.roundRect(left + tw + gap, cy - th, barW, th * 2, Math.min(barW / 2, 2), col);
}

function drawPrevIcon(cv, cx, cy, sz, col) {
    const tw = sz * 0.52, th = sz * 0.46;
    const barW = Math.max(3, Math.round(sz * 0.18));
    const gap = Math.max(3, Math.round(sz * 0.14));
    const totalW = tw + gap + barW;
    const left = cx - totalW / 2;
    cv.roundRect(left, cy - th, barW, th * 2, Math.min(barW / 2, 2), col);
    drawTriangle(cv,
        [left + barW + gap + tw, cy - th],
        [left + barW + gap, cy],
        [left + barW + gap + tw, cy + th],
        col
    );
}

/** A smooth S from (x0,y0) to (x1,y1): flat at both ends (a cubic ease), as points for a polyline. */
function sCurve(x0, y0, x1, y1, n) {
    const pts = [];
    for (let i = 0; i <= n; i++) {
        const u = i / n, e = u * u * (3 - 2 * u);
        pts.push([x0 + (x1 - x0) * u, y0 + (y1 - y0) * e]);
    }
    return pts;
}

/** An arrowhead (open chevron) at (x,y) pointing along angle dir (radians, 0 = right). */
function drawArrowHead(cv, x, y, dir, len, width, col) {
    [2.45, -2.45].forEach((a) => {
        cv.line(x, y, x + Math.cos(dir + a) * len, y + Math.sin(dir + a) * len, width, col);
    });
    cv.circle(x, y, width / 2, col);
}

function drawShuffleIcon(cv, cx, cy, sz, col) {
    const w = sz, h = sz * 0.56, lw = Math.max(2, sz * 0.1);
    const x0 = cx - w / 2, x1 = cx + w / 2 - lw;
    const y0 = cy - h / 2, y1 = cy + h / 2;
    const run = w * 0.18;                       // flat lead-in and lead-out
    // top-left to bottom-right, and bottom-left to top-right, crossing in the middle
    cv.polyline([[x0, y0]].concat(sCurve(x0 + run, y0, x1 - run, y1, 14), [[x1, y1]]), lw, col);
    cv.polyline([[x0, y1]].concat(sCurve(x0 + run, y1, x1 - run, y0, 14), [[x1, y0]]), lw, col);
    const ah = sz * 0.26;
    drawArrowHead(cv, x1 + lw * 0.4, y0, 0, ah, lw, col);
    drawArrowHead(cv, x1 + lw * 0.4, y1, 0, ah, lw, col);
}

function drawRepeatIcon(cv, cx, cy, sz, col, mode) {
    const w = sz, h = sz * 0.62, lw = Math.max(2, sz * 0.1);
    const r = h * 0.42, hl = lw / 2;
    const x0 = cx - w / 2, x1 = cx + w / 2, y0 = cy - h / 2, y1 = cy + h / 2;
    // a rounded loop, open at the top right where the arrow points into it
    cv.line(x0 + r, y0, x1 - r - sz * 0.22, y0, lw, col);                  // top (stops at the gap)
    cv.arc(x1 - r, y0 + r, r - hl, r + hl, 0, 90, col);                    // top-right corner
    cv.line(x1, y0 + r, x1, y1 - r, lw, col);
    cv.arc(x1 - r, y1 - r, r - hl, r + hl, 90, 180, col);
    cv.line(x1 - r, y1, x0 + r + sz * 0.22, y1, lw, col);                  // bottom (gap at the left)
    cv.arc(x0 + r, y1 - r, r - hl, r + hl, 180, 270, col);
    cv.line(x0, y1 - r, x0, y0 + r, lw, col);
    cv.arc(x0 + r, y0 + r, r - hl, r + hl, 270, 360, col);
    const ah = sz * 0.24;
    drawArrowHead(cv, x1 - r - sz * 0.22 + ah * 0.5, y0, 0, ah, lw, col);
    drawArrowHead(cv, x0 + r + sz * 0.22 - ah * 0.5, y1, Math.PI, ah, lw, col);
    if (mode === 'track') {
        // repeat one: a small "1" badge on the loop
        cv.circle(x1, y0, sz * 0.3, col);
        cv.text('1', x1, y0 + sz * 0.13, Math.round(sz * 0.38), '#000000', { align: 'center', font: 'bold' });
    }
}

/** A heart: two lobes and a point, filled, or as an outline. */
function drawHeartIcon(cv, cx, cy, sz, col, filled) {
    const r = sz * 0.27, d = r * 0.9;
    const ly = cy - sz * 0.5 + r + sz * 0.06;          // the lobes' centres
    const tipY = ly + d + 1.414 * r;
    const dip = ly - Math.sqrt(r * r - d * d);
    const lT = [cx - d - 0.707 * r, ly + 0.707 * r], rT = [cx + d + 0.707 * r, ly + 0.707 * r];
    if (filled) {
        cv.circle(cx - d, ly, r, col);
        cv.circle(cx + d, ly, r, col);
        cv.quad([lT, [cx, dip], rT, [cx, tipY]], col);
        return;
    }
    const lw = Math.max(2, sz * 0.1), hl = lw / 2;
    const tA = Math.atan2(d, ly - dip) * 180 / Math.PI;       // where the lobes meet, from each centre
    cv.arc(cx - d, ly, r - hl, r + hl, 225, 360, col);
    cv.arc(cx - d, ly, r - hl, r + hl, 0, tA, col);
    cv.arc(cx + d, ly, r - hl, r + hl, 360 - tA, 360, col);
    cv.arc(cx + d, ly, r - hl, r + hl, 0, 135, col);
    cv.line(lT[0], lT[1], cx, tipY, lw, col);
    cv.line(rT[0], rT[1], cx, tipY, lw, col);
    cv.circle(cx, tipY, hl, col);
}

/** A loading spinner: a faint ring and a turning arc (moves with each frame drawn). */
function drawSpinner(cv, cx, cy, r, col, lw) {
    lw = lw || Math.max(2, r * 0.3);
    const r0 = r - lw / 2, r1 = r + lw / 2;
    cv.arc(cx, cy, r0, r1, 0, 360, withAlpha(col, 0.2));
    const a0 = (Date.now() / 2.4) % 360, a1 = a0 + 110;
    if (a1 <= 360) cv.arc(cx, cy, r0, r1, a0, a1, col, { round: true });
    else {
        cv.arc(cx, cy, r0, r1, a0, 360, col, { round: true });
        cv.arc(cx, cy, r0, r1, 0, a1 - 360, col, { round: true });
    }
}

/** The row that closes a list while its next page loads: a spinner and what loads. */
function drawLoadingRow(cv, t, x, y, w, label, h) {
    h = h || 42;
    const size = sz(cv, 12.5);
    cv.roundRect(x, y, w, h, 8, withAlpha(t.track, 0.6));
    drawSpinner(cv, x + sz(cv, 18), y + h / 2, sz(cv, 7), t.accent);
    cv.text(label, x + sz(cv, 38), y + h / 2 + size * 0.36, size, t.dim);
}

/** A device's kind as a small line glyph (phone, computer, speaker, TV, car; others a speaker). */
function drawDeviceIcon(cv, cx, cy, type, col) {
    const k = String(type || '').toLowerCase();
    const lw = 2;
    if (k === 'smartphone' || k === 'tablet') {
        const w = k === 'tablet' ? 20 : 14, h = 24;
        cv.strokeRoundRect(cx - w / 2, cy - h / 2, w, h, 3, lw, col);
        cv.line(cx - 2.5, cy + h / 2 - 4, cx + 2.5, cy + h / 2 - 4, lw, col);
    } else if (k === 'computer') {
        cv.strokeRoundRect(cx - 13, cy - 11, 26, 17, 2, lw, col);
        cv.line(cx - 16, cy + 10, cx + 16, cy + 10, lw, col);
    } else if (k === 'tv') {
        cv.strokeRoundRect(cx - 14, cy - 10, 28, 18, 2, lw, col);
        cv.line(cx - 6, cy + 12, cx + 6, cy + 12, lw, col);
    } else if (k === 'automobile') {
        cv.strokeRoundRect(cx - 15, cy - 3, 30, 11, 4, lw, col);
        cv.line(cx - 9, cy - 3, cx - 5, cy - 10, lw, col);
        cv.line(cx - 5, cy - 10, cx + 6, cy - 10, lw, col);
        cv.line(cx + 6, cy - 10, cx + 10, cy - 3, lw, col);
        cv.circle(cx - 8, cy + 9, 3, col);
        cv.circle(cx + 8, cy + 9, 3, col);
    } else {
        cv.strokeRoundRect(cx - 10, cy - 13, 20, 26, 4, lw, col);
        cv.arc(cx, cy + 3, 4, 6, 0, 360, col);
        cv.circle(cx, cy - 7, 2, col);
    }
}

/** A spinner just left of a centred loading title (str drawn at cx, baseline y, this size). */
function drawSpinnerBefore(cv, str, cx, y, size, col) {
    const w = cv.textWidth ? cv.textWidth(str, size, { font: 'bold', spacing: 1 }) : str.length * size * 0.6;
    drawSpinner(cv, cx - w / 2 - size, y - size * 0.36, size * 0.42, col);
}

/** str cut (with "..") to fit maxW pixels at this size: room decides, not a character count. */
function fitText(cv, str, maxW, size, opts) {
    str = opts && opts.literal ? String(str || '') : translate(str || '');
    if (!cv.textWidth || cv.textWidth(str, size, opts) <= maxW) return str;
    let lo = 0, hi = str.length;
    while (lo < hi) {
        const mid = (lo + hi + 1) >> 1;
        if (cv.textWidth(str.slice(0, mid).replace(/\s+$/, '') + '..', size, opts) <= maxW) lo = mid; else hi = mid - 1;
    }
    return str.slice(0, lo).replace(/\s+$/, '') + '..';
}

mgu.run({
    async start(ctx) {
        const { ui, settings, log, dataDir } = ctx;
        const spotify = new SpotifyClient(ctx);
        const artManager = new AlbumArtManager(log, () => render());

        function notify(msg) {
            log.info('Spotify: ' + msg);
        }

        const cloudPair = new CloudPairManager(ctx, spotify);
        cloudPair.onPaired = () => {
            notify('Spotify Paired via Secure Cloud!');
            page = 0; // Automatically switch to Playlists upon pairing!
            spotify.initialFetch();
            render().catch(() => {});
        };
        cloudPair.onUnpaired = () => {
            spotify.logout();
            cachedQr = null;
            cachedQrUrl = null;
            cloudPair.reset();
            cloudPair.startPolling();
            artManager.load(null);
            page = 3;
            notify('Spotify Disconnected.');
            render().catch(() => {});
        };
        // background: no internet checks, no player polls and no relay stream (its keepalives would
        // wake the app all drive); what the phone sent meanwhile is read when the screen is back
        // (the relay keeps 12 h), as M-Copilot does
        const onScreen = () => !ui.isVisible || ui.isVisible('MAIN');
        spotify.isOnScreen = onScreen;
        if (ui.onVisible) ui.onVisible((name, visible) => {
            if (name !== 'MAIN') return;
            if (visible) cloudPair.startPolling(); else cloudPair.stopPolling();
        });
        if (onScreen()) cloudPair.startPolling();

        // Default to Online mode (demo !== 'on')
        // If not authenticated, open directly on the Connect tab!
        // read each time: the demo setting can change while the app runs
        const isOnlineMode = () => settings.get('demo') !== 'on';
        let page = (isOnlineMode() && !spotify.isAuthenticated()) ? 3 : 0;
        let showPhoneQr = false;        // Connect, paired: the phone page's QR code in place of the account card
        // the demo switched on or off (Settings, or the offline screen's button): its data in or out
        settings.onChange((k, v) => {
            if (k !== 'demo') return;
            spotify.setDemoMode(v === 'on');
            if (v !== 'on' && !spotify.isAuthenticated()) page = 3;      // to the pairing QR
            render();
        });
        let selectedPlaylistIdx = 0;
        let playlistScroll = 0;
        let trackScroll = 0;
        let likedScroll = 0;
        let queueScroll = 0;

        /*
         * Busy buttons. A tap that has to wait for Spotify (or the network) marks its button busy:
         * it shows a spinner and takes no other tap until the answer is in, so a slow phone is not
         * sent the same command twice. One key per group of buttons that must not overlap:
         *   start     a song started from a list (id: the row)    transport  play/pause, next, previous
         *   shuffle, repeat, like      devices  refresh            transfer   moving playback (id: device)
         *   playlists refresh          net      the internet check
         * A request that never answers frees its button after BUSY_MAX_MS.
         */
        const BUSY_MAX_MS = 12000;
        const busy = {};
        const isBusy = (key) => !!busy[key] && Date.now() - busy[key].at < BUSY_MAX_MS;
        const busyOn = (key, id) => isBusy(key) && busy[key].id === id;
        function runBusy(key, fn, id) {
            if (isBusy(key)) return;
            const mark = { at: Date.now(), id };
            busy[key] = mark;
            let p;
            try { p = Promise.resolve(fn()); } catch (e) { p = Promise.resolve(); log.warn(key + ': ' + e.message); }
            const done = () => { if (busy[key] === mark) delete busy[key]; render(); };
            p.then(done, done);
            render();
        }

        // "Playing" marks follow what Spotify plays (its context and track), not what is selected here
        const playingFrom = (pl) => !!(pl && pl.uri && spotify.contextUri && spotify.contextUri === pl.uri);
        const isPlayingTrack = (trk) => !!(trk && spotify.currentTrack && spotify.currentTrack.id === trk.id);

        // Lists scroll with a finger (the list under it) or the controller (the page's main list).
        // listGeo is filled while a page draws: rows per list, how many show, the list's x range.
        const listGeo = {};
        const scrollGet = { pl: () => playlistScroll, trk: () => trackScroll, liked: () => likedScroll, q: () => queueScroll };
        const scrollSet = { pl: (v) => { playlistScroll = v; }, trk: (v) => { trackScroll = v; }, liked: (v) => { likedScroll = v; }, q: (v) => { queueScroll = v; } };
        let scrollAcc = 0, scrollList = null;
        ctx.onScroll((dy, at) => {
            const names = page === 0 ? ['pl', 'trk'] : page === 1 ? ['liked'] : page === 2 ? ['q'] : [];
            const name = names.find((n) => at && listGeo[n] && at.x >= listGeo[n].x0 && at.x < listGeo[n].x1) || names[names.length - 1];
            const g = name && listGeo[name];
            if (!g) return false;
            if (name !== scrollList) { scrollList = name; scrollAcc = 0; }
            const max = Math.max(0, g.count - g.visible), cur = scrollGet[name]();
            scrollAcc += dy;
            const rows = scrollAcc > 0 ? Math.floor(scrollAcc / g.rowH) : Math.ceil(scrollAcc / g.rowH);
            if (!rows) return (dy > 0 && cur < max) || (dy < 0 && cur > 0);
            scrollAcc -= rows * g.rowH;
            const next = Math.max(0, Math.min(max, cur + rows));
            scrollSet[name](next);
            render().catch(() => {});
            return next !== cur;
        });
        let spectrumSeed = 0;

        /* ---------- Real Cloud Pairing QR Code Generation ---------- */
        let cachedQr = null;
        let cachedQrUrl = null;
        function getQrMatrix() {
            // Use real public pairing URL (works anywhere over 4G/5G/Wi-Fi, zero 127.0.0.1)
            const url = cloudPair.getPairingUrl();
            if (cachedQr && cachedQrUrl === url) return cachedQr;
            try {
                const qr = qrcodegen.QrCode.encodeText(url, qrcodegen.QrCode.Ecc.MEDIUM);
                cachedQr = qr;
                cachedQrUrl = url;
                return qr;
            } catch (e) {
                return null;
            }
        }

        /* ---------- Offline Safeguard Screen: No Internet Connection ---------- */
        function drawNoInternet(cv, t) {
            G.panel(cv, t, 24, 44, 1552, 468, 'Network Status: Offline');

            cv.roundRect(48, 100, 1504, 388, 16, '#0f141f');
            cv.strokeRoundRect(48, 100, 1504, 388, 16, 2, '#e1001a');

            cv.circle(148, 250, 48, withAlpha('#e1001a', 0.2));
            cv.text('!', 148, 266, 50, '#e1001a', { align: 'center', font: 'bold' });

            cv.text('NO INTERNET CONNECTION', 228, 195, 28, '#e1001a', { font: 'bold', spacing: 1 });
            cv.text('Spotify Online requires an active internet connection on your vehicle.', 228, 240, 19, '#ffffff');
            cv.text('Please verify that your BMW has cellular data or is connected to a mobile Wi-Fi hotspot.', 228, 276, 17, '#94a3b8');

            // Action Buttons: [RETRY CONNECTION] and [SWITCH TO DEMO MODE]
            const btnW = 280, btnH = 52, btnY = 345;
            const b1X = 228;
            const netBusy = isBusy('net');
            cv.roundRect(b1X, btnY, btnW, btnH, 10, netBusy ? '#00365f' : '#004e8c');
            cv.strokeRoundRect(b1X, btnY, btnW, btnH, 10, 1.5, '#00a3e0');
            if (netBusy) {
                drawSpinner(cv, b1X + 62, btnY + btnH / 2, 10, '#ffffff');
                cv.text('CHECKING...', b1X + btnW / 2 + 14, btnY + 32, 16, '#cbd5e1', { align: 'center', font: 'bold', spacing: 1 });
            } else {
                cv.text('RETRY CONNECTION', b1X + btnW / 2, btnY + 32, 16, '#ffffff', { align: 'center', font: 'bold', spacing: 1 });
            }
            cv.target(b1X, btnY, btnW, btnH, () => {
                runBusy('net', () => spotify.checkInternetConnection());
            }, 'btn_retry_net', 15);

            const b2X = b1X + btnW + 24;
            cv.roundRect(b2X, btnY, btnW, btnH, 10, '#1a2332');
            cv.strokeRoundRect(b2X, btnY, btnW, btnH, 10, 1, '#334155');
            cv.text('SWITCH TO DEMO MODE', b2X + btnW / 2, btnY + 32, 15, '#cbd5e1', { align: 'center', font: 'bold' });
            cv.target(b2X, btnY, btnW, btnH, () => {
                settings.set('demo', 'on');          // the change handler brings the demo in
            }, 'btn_switch_demo', 15);
        }

        /* ---------- Gating Screen: Authentication Required in Online Mode ---------- */
        function drawRequireConnect(cv, t) {
            G.panel(cv, t, 24, 44, 1552, 468, 'Spotify Login Required');

            cv.roundRect(48, 100, 1504, 388, 16, '#0c1522');
            cv.strokeRoundRect(48, 100, 1504, 388, 16, 2, '#1ed760');

            cv.circle(148, 250, 48, withAlpha('#1ed760', 0.2));
            drawPlayIcon(cv, 151, 250, 36, '#1ed760');

            cv.text('SPOTIFY LOGIN REQUIRED', 228, 195, 28, '#ffffff', { font: 'bold', spacing: 1 });
            cv.text('Online Mode is active. Please pair your personal Spotify account to browse your library and control playback.', 228, 240, 18, '#cbd5e1');
            cv.text('Scan the QR code with your phone to sync your playlists and Spotify Connect target devices.', 228, 276, 16, '#94a3b8');

            const btnW = 340, btnH = 52, btnY = 345, bX = 228;
            cv.roundRect(bX, btnY, btnW, btnH, 10, '#1ed760');
            cv.text('PAIR PHONE (SCAN QR CODE)', bX + btnW / 2, btnY + 32, 16, '#000000', { align: 'center', font: 'bold', spacing: 1 });
            cv.target(bX, btnY, btnW, btnH, () => {
                page = 3; // Switch to Connect tab
            }, 'btn_goto_connect', 15);
        }

        /* ---------- Bottom Now Playing Player Dock ---------- */
        function drawBottomPlayerDock(cv, t) {
            const curTrk = spotify.currentTrack;
            const isPlaying = spotify.isPlaying;
            const m = metrics(cv);
            const dockX = 24, dockY = m.dockY, dockW = 1552, dockH = m.dockH;

            // Dock backdrop & border
            cv.roundRect(dockX, dockY, dockW, dockH, 12, withAlpha(t.panelEdge, 0.9));
            cv.strokeRoundRect(dockX, dockY, dockW, dockH, 12, 1, isPlaying ? withAlpha(t.accent, 0.4) : withAlpha(t.panelEdge, 0.8));

            // Mini artwork / Equalizer box
            const miniSz = dockH - 18, miniX = dockX + 10, miniY = dockY + 9;
            cv.roundRect(miniX, miniY, miniSz, miniSz, 8, withAlpha(t.panelEdge, 0.9));
            if (artManager.hasArt) {
                cv.image(ART_IMG_ID, miniX, miniY, miniSz, miniSz, miniSz * 0.07);   // (the GPU rounds the corners smoothly; art.js cuts them for software)
                cv.strokeRoundRect(miniX, miniY, miniSz, miniSz, 8, 1, withAlpha(t.accent, 0.35));
            } else {
                cv.strokeRoundRect(miniX, miniY, miniSz, miniSz, 8, 1, withAlpha(t.accent, 0.3));
                drawMiniEqualizer(cv, miniX + miniSz / 2, miniY + miniSz / 2, isPlaying ? t.accent : t.dim, isPlaying, spectrumSeed);
            }

            // Controls on the right, from the dock's right end: Now Playing button, Next, Play / Pause, Prev
            const bh = sz(cv, 36), by = dockY + (dockH - bh) / 2, gap = sz(cv, 10);
            const npW = sz(cv, 124), npX = dockX + dockW - 16 - npW;
            const skW = sz(cv, 46), nextX = npX - sz(cv, 18) - skW;
            const playW = sz(cv, 60), playH = sz(cv, 42), playX = nextX - gap - playW, playY = dockY + (dockH - playH) / 2;
            const prevX = playX - gap - skW;

            // Track metadata: up to the time, left of the controls
            const timeW = sz(cv, 100), timeX = prevX - sz(cv, 24) - timeW / 2;
            const textX = miniX + miniSz + 14, dockTextW = timeX - timeW / 2 - 16 - textX;
            const tSize = sz(cv, 15), mSize = sz(cv, 12);
            const tY = dockY + dockH / 2 - 3, mY = tY + mSize + 6;
            if (curTrk) {
                cv.text(fitText(cv, curTrk.title, dockTextW, tSize, MEDIA_BOLD), textX, tY, tSize, isPlaying ? t.accent : t.text, MEDIA_BOLD);
                const metaStr = curTrk.artist + (curTrk.album ? '  -  ' + curTrk.album : '');
                cv.text(fitText(cv, metaStr, dockTextW, mSize, MEDIA), textX, mY, mSize, t.dim, MEDIA);
            } else {
                cv.text('No Track Playing', textX, tY, tSize, t.dim, { font: 'bold' });
                cv.text(fitText(cv, 'Select any song from Playlists or Liked Songs to begin', dockTextW, mSize), textX, mY, mSize, t.dim);
            }

            // Tapping the track's part opens the full Now Playing screen
            cv.target(dockX, dockY, prevX - 12 - dockX, dockH, () => {
                page = 2; // Switch to Now Playing screen
                render();
            }, 'dock_open_np', 10);

            // Elapsed / Duration timestamp
            if (curTrk) {
                cv.text(fmtTime(spotify.progressMs) + ' / ' + fmtTime(curTrk.durationMs), timeX, dockY + dockH / 2 + sz(cv, 4.5), sz(cv, 12.5), t.dim, { align: 'center', font: 'num' });
            }

            // 1. Prev
            cv.roundRect(prevX, by, skW, bh, 8, withAlpha(t.panelEdge, 0.7));
            if (busyOn('transport', 'prev')) drawSpinner(cv, prevX + skW / 2, by + bh / 2, sz(cv, 8), t.text);
            else drawPrevIcon(cv, prevX + skW / 2, by + bh / 2, sz(cv, 14), isBusy('transport') ? t.dim : t.text);
            cv.target(prevX, by, skW, bh, () => {
                runBusy('transport', () => spotify.prevTrack(), 'prev');
            }, 'dock_prev', 12);

            // 2. Play / Pause
            cv.roundRect(playX, playY, playW, playH, playH / 2, isBusy('transport') ? withAlpha(t.accent, 0.6) : t.accent);
            if (busyOn('transport', 'play')) {
                drawSpinner(cv, playX + playW / 2, playY + playH / 2, sz(cv, 9), '#000000');
            } else if (isPlaying) {
                drawPauseIcon(cv, playX + playW / 2, playY + playH / 2, sz(cv, 15), '#000000');
            } else {
                drawPlayIcon(cv, playX + playW / 2, playY + playH / 2, sz(cv, 15), '#000000');
            }
            cv.target(playX, playY, playW, playH, () => {
                runBusy('transport', () => spotify.togglePlay(), 'play');
            }, 'dock_play', playH / 2);

            // 3. Next
            cv.roundRect(nextX, by, skW, bh, 8, withAlpha(t.panelEdge, 0.7));
            if (busyOn('transport', 'next')) drawSpinner(cv, nextX + skW / 2, by + bh / 2, sz(cv, 8), t.text);
            else drawNextIcon(cv, nextX + skW / 2, by + bh / 2, sz(cv, 14), isBusy('transport') ? t.dim : t.text);
            cv.target(nextX, by, skW, bh, () => {
                runBusy('transport', () => spotify.nextTrack(), 'next');
            }, 'dock_next', 12);

            // 4. "NOW PLAYING >" button
            cv.roundRect(npX, by, npW, bh, 8, withAlpha(t.accent, 0.2));
            cv.strokeRoundRect(npX, by, npW, bh, 8, 1, withAlpha(t.accent, 0.4));
            const npSize = sz(cv, 11);
            cv.text('NOW PLAYING >', npX + npW / 2, by + bh / 2 + npSize * 0.36, npSize, t.accent, { align: 'center', font: 'bold', spacing: 0.5 });
            cv.target(npX, by, npW, bh, () => {
                page = 2; // Switch to Now Playing screen
                render();
            }, 'dock_btn_np', 12);

            // Thin progress line along the bottom edge of dock
            const dur = (curTrk && curTrk.durationMs) ? curTrk.durationMs : 1;
            const pFrac = Math.min(1, Math.max(0, spotify.progressMs / dur));
            cv.roundRect(dockX + 4, dockY + dockH - 4, dockW - 8, 3, 1.5, t.tick);
            if (pFrac > 0) {
                cv.roundRect(dockX + 4, dockY + dockH - 4, Math.round((dockW - 8) * pFrac), 3, 1.5, t.accent);
            }
        }

        /**
         * A song row (playlist songs, Liked Songs), m.songH high at y: number (or the equalizer / a spinner while it
         * plays or starts), a heart (heart: Liked Songs), title, artist - album, length and a PLAYING tag.
         * o = { x, w, y, idx, trk, playing, starting, heart }
         */
        function drawSongRow(cv, t, m, o) {
            const { x, w, y, trk } = o, h = m.songH, cy = y + h / 2;
            const base = (size) => cy + size * 0.36;
            if (o.playing) {
                cv.roundRect(x, y, w, h, 8, withAlpha(t.accent, 0.22));
                cv.strokeRoundRect(x, y, w, h, 8, 1.5, t.accent);
                if (o.starting) drawSpinner(cv, x + sz(cv, 18), cy, sz(cv, 7), t.accent);
                else drawMiniEqualizer(cv, x + sz(cv, 18), cy, t.accent, spotify.isPlaying, spectrumSeed);
            } else {
                cv.roundRect(x, y, w, h, 8, t.track);
                cv.text(String(o.idx + 1), x + sz(cv, 18), base(m.num), m.num, t.dim, { align: 'center', font: 'num' });
            }
            let tx = x + sz(cv, 42);
            if (o.heart) { drawHeartIcon(cv, tx + sz(cv, 8), cy, sz(cv, 13), '#1ed760', true); tx += sz(cv, 28); }
            // the PLAYING tag at the right end, the length left of it; the columns never overlap
            const tagW = sz(cv, 58), tagH = Math.round(h * 0.56), tagX = x + w - 12 - tagW;
            const timeR = o.playing ? tagX - 14 : x + w - 22;
            const metaX = x + Math.round(w * (o.heart ? 0.42 : 0.36));
            const metaR = timeR - sz(cv, 48);
            cv.text(fitText(cv, trk.title, metaX - 18 - tx, m.title, MEDIA_BOLD), tx, base(m.title), m.title, o.playing ? t.accent : t.text, MEDIA_BOLD);
            const metaText = trk.artist + (trk.album ? '  -  ' + trk.album : '');
            cv.text(fitText(cv, metaText, metaR - metaX, m.meta, MEDIA), metaX, base(m.meta), m.meta, t.dim, MEDIA);
            cv.text(fmtTime(trk.durationMs), timeR, base(m.num), m.num, t.dim, { align: 'right', font: 'num' });
            if (o.playing) {
                const ts = sz(cv, 9.5);
                cv.roundRect(tagX, cy - tagH / 2, tagW, tagH, 6, o.starting ? withAlpha(t.accent, 0.35) : t.accent);
                cv.text(o.starting ? 'WAIT' : 'PLAYING', tagX + tagW / 2, cy + ts * 0.36, ts, o.starting ? t.accent : '#000000', { align: 'center', font: 'bold' });
            }
        }

        /* ---------- Page 0: Playlists & Tracks ---------- */
        function drawPlaylists(cv, t) {
            const playlists = spotify.getPlaylists();

            if (!playlists || playlists.length === 0) {
                if (isOnlineMode() && !spotify.isAuthenticated()) {
                    drawRequireConnect(cv, t);
                } else {
                    G.panelExact(cv, t, 24, 44, 1552, metrics(cv).panelH, 'Your Playlists (0)');

                    cv.roundRect(48, 100, 1504, 200, 12, t.track);
                    cv.strokeRoundRect(48, 100, 1504, 200, 12, 1, t.panelEdge);

                    const loading = spotify.isLoadingPlaylists || spotify.syncing;
                    cv.text(loading ? 'LOADING PLAYLISTS...' : 'NO PLAYLISTS FOUND', 800, 175, 22, t.dim, { align: 'center', font: 'bold', spacing: 1 });
                    if (loading) drawSpinnerBefore(cv, 'LOADING PLAYLISTS...', 800, 175, 22, t.accent);
                    cv.text(loading ? 'Fetching your playlists from Spotify cloud...' : 'Create or follow playlists on Spotify, or browse Liked Songs.', 800, 210, 16, t.dim, { align: 'center' });

                    const rfW = 240, rfH = 44, rfX = 680, rfY = 236;
                    const plBusy = isBusy('playlists') || spotify.isLoadingPlaylists;
                    cv.roundRect(rfX, rfY, rfW, rfH, 8, withAlpha(t.accent, plBusy ? 0.1 : 0.22));
                    cv.strokeRoundRect(rfX, rfY, rfW, rfH, 8, 1.5, withAlpha(t.accent, plBusy ? 0.5 : 1));
                    if (plBusy) {
                        drawSpinner(cv, rfX + 40, rfY + rfH / 2, 9, t.accent);
                        cv.text('LOADING...', rfX + rfW / 2 + 12, rfY + 27, 14, withAlpha(t.accent, 0.8), { align: 'center', font: 'bold', spacing: 1 });
                    } else {
                        cv.text('REFRESH PLAYLISTS', rfX + rfW / 2, rfY + 27, 14, t.accent, { align: 'center', font: 'bold', spacing: 1 });
                    }
                    cv.target(rfX, rfY, rfW, rfH, () => {
                        if (!spotify.isLoadingPlaylists) runBusy('playlists', () => spotify.fetchPlaylists());
                    }, 'btn_refresh_pls', 12);

                    drawBottomPlayerDock(cv, t);
                }
                return;
            }

            // Keep selected index valid
            if (selectedPlaylistIdx >= playlists.length) selectedPlaylistIdx = 0;

            // Visible window for playlists (scrolled freely: not pulled back to the selection)
            const m = metrics(cv), listH = m.listBottom - m.listTop;
            const VISIBLE_PL = Math.max(1, Math.floor((listH + 8) / m.plStep));
            playlistScroll = Math.max(0, Math.min(playlistScroll, Math.max(0, playlists.length - VISIBLE_PL)));
            listGeo.pl = { x0: 24, x1: 532, rowH: m.plStep, count: playlists.length, visible: VISIBLE_PL };
            cv.scroll = true;

            // Left Pane: Playlists (w: 500)
            const plTitle = message('Your Playlists ({selected}/{total})', { selected: selectedPlaylistIdx + 1, total: playlists.length });
            G.panelExact(cv, t, 24, 44, 500, m.panelH, plTitle);

            // Left Pane Scrollbar
            drawScrollbar(cv, t, 508, m.listTop, listH, playlists.length, VISIBLE_PL, playlistScroll, () => {
                playlistScroll = Math.max(0, playlistScroll - 1);
                selectedPlaylistIdx = Math.max(0, selectedPlaylistIdx - 1);
                spotify.selectPlaylist(playlists[selectedPlaylistIdx]);
            }, () => {
                playlistScroll = Math.min(Math.max(0, playlists.length - VISIBLE_PL), playlistScroll + 1);
                selectedPlaylistIdx = Math.min(playlists.length - 1, selectedPlaylistIdx + 1);
                spotify.selectPlaylist(playlists[selectedPlaylistIdx]);
            });

            const visiblePlaylists = playlists.slice(playlistScroll, playlistScroll + VISIBLE_PL);
            visiblePlaylists.forEach((pl, vIdx) => {
                const realIdx = playlistScroll + vIdx;
                const py = m.listTop + vIdx * m.plStep, ph = m.plH;
                const isSel = realIdx === selectedPlaylistIdx;
                const isPlPlaying = playingFrom(pl);       // the playlist Spotify plays from, selected or not

                cv.roundRect(38, py, 460, ph, 10, isSel ? withAlpha(t.accent, 0.22) : t.track);
                if (isSel) cv.strokeRoundRect(38, py, 460, ph, 10, 2, t.accent);

                // Accent tag
                cv.roundRect(44, py + 8, 5, ph - 16, 2.5, isPlPlaying ? t.accent : (pl.accent || t.accent));
                const plTextW = (isPlPlaying ? 452 : 486) - 62;     // up to the equalizer, or the row's end
                const nSize = sz(cv, 17), dSize = sz(cv, 12.5);
                const nY = py + ph / 2 - (ph * 0.06), dY = nY + dSize + ph * 0.14;
                cv.text(fitText(cv, pl.name, plTextW, nSize, MEDIA_BOLD), 62, nY, nSize, isSel ? t.text : '#e0e0e0', MEDIA_BOLD);
                cv.text(fitText(cv, message('{count} songs', { count: pl.trackCount || 0 }) + '  -  ' + (pl.description || translate('Playlist')), plTextW, dSize, MEDIA), 62, dY, dSize, t.dim, MEDIA);

                if (isPlPlaying) {
                    drawMiniEqualizer(cv, 470, py + ph / 2, t.accent, spotify.isPlaying, spectrumSeed);
                }

                cv.target(38, py, 460, ph, () => {
                    selectedPlaylistIdx = realIdx;
                    trackScroll = 0;
                    spotify.selectPlaylist(pl);
                }, 'pl_' + realIdx, 10);
            });

            // Right Pane: Tracks of selected playlist (x: 540, w: 1036, h: 396)
            const curPl = playlists[selectedPlaylistIdx] || playlists[0];
            // the track that plays, in this playlist (another playlist's context marks nothing here)
            const ctxHere = !spotify.contextUri || !/:playlist:/.test(spotify.contextUri) || playingFrom(curPl);
            const trackTotal = curPl.trackCount || (curPl.tracks ? curPl.tracks.length : 0);

            G.panelExact(cv, t, 540, 44, 1036, metrics(cv).panelH, fitText(cv, curPl.name, 760, 26, MEDIA_BOLD) + ' (' + message('{count} tracks', { count: trackTotal }) + ')', MEDIA);

            // the songs of the playlist shown: fetched (and retried) from here, whatever selected it
            spotify.ensureTracks(curPl);

            if (!curPl.tracks || curPl.tracks.length === 0) {
                const none = !!curPl.tracksLoaded;
                cv.roundRect(556, 120, 1004, 180, 12, t.track);
                cv.text(none ? 'NO SONGS' : 'LOADING SONGS...', 1058, 195, 22, t.dim, { align: 'center', font: 'bold', spacing: 1 });
                if (!none) drawSpinnerBefore(cv, 'LOADING SONGS...', 1058, 195, 22, t.accent);
                cv.text(none ? 'This playlist has no songs that can be played here.' : 'Fetching track list from Spotify cloud...', 1058, 230, 16, t.dim, { align: 'center' });
            } else {
                const m = metrics(cv), listH = m.listBottom - m.listTop;
                const VISIBLE_TRK = Math.max(1, Math.floor((listH + 6) / m.songStep));
                // more songs than loaded: a "loading" row closes the list, and the next page comes
                // as the list nears its end
                const moreTrk = spotify.hasMoreTracks(curPl);
                const trkRows = curPl.tracks.length + (moreTrk ? 1 : 0);
                trackScroll = Math.max(0, Math.min(trackScroll, Math.max(0, trkRows - VISIBLE_TRK)));
                listGeo.trk = { x0: 540, x1: 1576, rowH: m.songStep, count: trkRows, visible: VISIBLE_TRK };
                if (moreTrk && trackScroll + VISIBLE_TRK >= curPl.tracks.length - 5) spotify.loadMoreTracks(curPl);

                // Right Pane Tracks Scrollbar
                drawScrollbar(cv, t, 1554, m.listTop, listH, trkRows, VISIBLE_TRK, trackScroll, () => {
                    trackScroll = Math.max(0, trackScroll - VISIBLE_TRK);
                }, () => {
                    trackScroll = Math.min(Math.max(0, trkRows - VISIBLE_TRK), trackScroll + VISIBLE_TRK);
                });

                const visibleTracks = curPl.tracks.slice(trackScroll, trackScroll + VISIBLE_TRK);
                if (moreTrk && trackScroll + VISIBLE_TRK > curPl.tracks.length) {
                    drawLoadingRow(cv, t, 556, m.listTop + (curPl.tracks.length - trackScroll) * m.songStep, 980,
                        message('Loading more songs ({loaded} of {total})...', { loaded: curPl.tracks.length, total: curPl._total || trackTotal }), m.songH);
                }

                visibleTracks.forEach((trk, vIdx) => {
                    const realIdx = trackScroll + vIdx;
                    const ty = m.listTop + vIdx * m.songStep;
                    const startKey = 'pl:' + curPl.id + ':' + realIdx;
                    const starting = busyOn('start', startKey);
                    const isPlayingThis = starting || (ctxHere && isPlayingTrack(trk));
                    drawSongRow(cv, t, m, { x: 556, w: 980, y: ty, idx: realIdx, trk, playing: isPlayingThis, starting });
                    cv.target(556, ty, 980, m.songH, () => {
                        runBusy('start', () => spotify.playTrack(curPl, realIdx), startKey);
                    }, 'trk_' + realIdx, 8);
                });
            }

            // Bottom Player Dock
            drawBottomPlayerDock(cv, t);
        }

        /* ---------- Page 1: Liked Songs ---------- */
        function drawLibrary(cv, t) {
            if (isOnlineMode() && !spotify.isAuthenticated()) {
                drawRequireConnect(cv, t);
                return;
            }

            const liked = (spotify.likedSongs && spotify.likedSongs.length)
                ? spotify.likedSongs
                : (spotify.isDemoMode ? require('./api').DEMO_PLAYLISTS[3].tracks : []);

            const total = spotify.likedTotal || liked.length;
            const m = metrics(cv), listH = m.listBottom - m.listTop;
            const VISIBLE_LIKED = Math.max(1, Math.floor((listH + 6) / m.songStep));
            // more liked songs than loaded: a "loading" row closes the list, the next page comes near its end
            const moreLiked = liked === spotify.likedSongs && spotify.hasMoreLiked();
            const likedRows = liked.length + (moreLiked ? 1 : 0);
            likedScroll = Math.max(0, Math.min(likedScroll, Math.max(0, likedRows - VISIBLE_LIKED)));
            listGeo.liked = { x0: 24, x1: 1576, rowH: m.songStep, count: likedRows, visible: VISIBLE_LIKED };
            if (moreLiked && likedScroll + VISIBLE_LIKED >= liked.length - 5) spotify.loadMoreLiked();
            cv.scroll = true;
            const startIdx = total > 0 ? likedScroll + 1 : 0;
            const endIdx = Math.min(likedScroll + VISIBLE_LIKED, liked.length, total);
            const title = message('Liked Songs ({range})', { range: total > 0 ? message('{start}-{end} of {total} tracks', { start: startIdx, end: endIdx, total }) : translate('0 tracks') });

            G.panelExact(cv, t, 24, 44, 1552, m.panelH, title);

            // Liked Songs Scrollbar
            drawScrollbar(cv, t, 1554, m.listTop, listH, likedRows, VISIBLE_LIKED, likedScroll, () => {
                likedScroll = Math.max(0, likedScroll - VISIBLE_LIKED);
            }, () => {
                likedScroll = Math.min(Math.max(0, likedRows - VISIBLE_LIKED), likedScroll + VISIBLE_LIKED);
            });

            if (!liked || liked.length === 0) {
                cv.roundRect(48, 100, 1504, 200, 12, t.track);
                cv.strokeRoundRect(48, 100, 1504, 200, 12, 1, t.panelEdge);
                const loading = spotify.isLoadingLiked || spotify.syncing;
                cv.text(loading ? 'LOADING LIKED SONGS...' : 'NO LIKED SONGS FOUND', 800, 180, 22, t.dim, { align: 'center', font: 'bold', spacing: 1 });
                if (loading) drawSpinnerBefore(cv, 'LOADING LIKED SONGS...', 800, 180, 22, t.accent);
                cv.text(loading ? 'Fetching your saved songs from Spotify cloud...' : 'Like songs on Spotify to access them directly here.', 800, 215, 16, t.dim, { align: 'center' });
                drawBottomPlayerDock(cv, t);
                return;
            }

            const visible = liked.slice(likedScroll, likedScroll + VISIBLE_LIKED);
            if (moreLiked && likedScroll + VISIBLE_LIKED > liked.length) {
                drawLoadingRow(cv, t, 40, m.listTop + (liked.length - likedScroll) * m.songStep, 1500,
                    message('Loading more liked songs ({loaded} of {total})...', { loaded: liked.length, total }), m.songH);
            }
            visible.forEach((trk, vIdx) => {
                const realIdx = likedScroll + vIdx;
                const ty = m.listTop + vIdx * m.songStep;
                const startKey = 'liked:' + realIdx;
                const starting = busyOn('start', startKey);
                const isPlayingThis = starting || isPlayingTrack(trk);
                drawSongRow(cv, t, m, { x: 40, w: 1500, y: ty, idx: realIdx, trk, playing: isPlayingThis, starting, heart: true });

                cv.target(40, ty, 1500, m.songH, () => {
                    runBusy('start', () => spotify.playLikedSong(realIdx), startKey);
                }, 'liked_' + realIdx, 8);
            });

            // Bottom Player Dock
            drawBottomPlayerDock(cv, t);
        }

        /* ---------- Page 2: Now Playing & Queue ---------- */
        function drawNowPlaying(cv, t) {
            if (isOnlineMode() && !spotify.isAuthenticated()) {
                drawRequireConnect(cv, t);
                return;
            }

            const curTrk = spotify.currentTrack;
            const isPlaying = spotify.isPlaying;
            const npEx = cv.extra || 0;        // the panels reach the screen's bottom: controls move with it

            // Left Pane: Now Playing Cockpit (w: 880, h: 468)
            G.panel(cv, t, 24, 44, 880, 468, 'Now Playing');

            if (!curTrk) {
                cv.roundRect(48, 120, 832, 220, 12, t.track);
                cv.text('NO TRACK PLAYING', 464, 215, 22, t.dim, { align: 'center', font: 'bold', spacing: 1 });
                cv.text('Select any song from Playlists or Liked Songs to begin playback.', 464, 255, 16, t.dim, { align: 'center' });
            } else {
                // Vinyl / Album Art Box
                const artX = 54, artY = 104, artSz = Math.min(244, sz(cv, 190));      // as tall as the room over the progress bar allows
                cv.roundRect(artX, artY, artSz, artSz, 14, '#0c1015');

                if (artManager.hasArt) {
                    cv.image(ART_IMG_ID, artX, artY, artSz, artSz, artSz * 0.07);
                    cv.strokeRoundRect(artX, artY, artSz, artSz, 14, 1.5, isPlaying ? withAlpha(t.accent, 0.4) : withAlpha(t.panelEdge, 0.8));
                } else {
                    cv.strokeRoundRect(artX, artY, artSz, artSz, 14, 1.5, isPlaying ? withAlpha(t.accent, 0.4) : withAlpha(t.panelEdge, 0.8));

                    // Vinyl disc representation
                    const cx = artX + artSz / 2, cy = artY + artSz / 2;
                    cv.circle(cx, cy, 98, '#07090c');
                    cv.circle(cx, cy, 80, '#12161c');
                    cv.circle(cx, cy, 60, '#0a0d12');
                    cv.circle(cx, cy, 40, isPlaying ? withAlpha(t.accent, 0.3) : withAlpha(t.panelEdge, 0.5));
                    cv.circle(cx, cy, 14, isPlaying ? t.accent : t.dim);

                    // Multi-bar animated visualizer in center
                    drawMiniEqualizer(cv, cx, cy, '#ffffff', isPlaying, spectrumSeed);
                }

                // Right of Album Art: Track Info, as wide as the panel lets it be
                const metaX = artX + artSz + 26, metaW = 880 - metaX;
                const devSize = sz(cv, 10.5), devH = sz(cv, 24), tSize = sz(cv, 27), aSize = sz(cv, 18), alSize = sz(cv, 14);
                const devY = 106, titleY = devY + devH + 14 + tSize, artistY = titleY + aSize + 14, albumY = artistY + alSize + 12;

                // where it plays: a pill as wide as its text, a live dot when music plays
                const devOpts = { font: 'bold', spacing: 1, literal: true };
                const devName = spotify.activeDevice || '';
                const devLabel = !devName ? 'SPOTIFY CONNECT'
                    : spotify.stalled ? devName + '  -  ' + translate('NOT RESPONDING')
                    : translate(isPlaying ? 'PLAYING ON  ' : 'PAUSED ON  ') + devName;
                const devText = fitText(cv, devLabel, metaW - 20 - devH * 1.5, devSize, devOpts);
                const devW = cv.textWidth(devText, devSize, devOpts) + devH * 1.5 + 14;
                cv.roundRect(metaX, devY, devW, devH, devH / 2, withAlpha(t.accent, 0.16));
                cv.circle(metaX + devH * 0.6, devY + devH / 2, devH * 0.16, isPlaying ? t.accent : withAlpha(t.accent, 0.45));
                cv.text(devText, metaX + devH * 1.1, devY + devH / 2 + devSize * 0.36, devSize, t.accent, devOpts);

                // Title, artist, album: cut only where the panel ends
                cv.text(fitText(cv, curTrk.title, metaW, tSize, MEDIA_BOLD), metaX, titleY, tSize, t.text, MEDIA_BOLD);
                cv.text(fitText(cv, curTrk.artist, metaW, aSize, MEDIA), metaX, artistY, aSize, '#d4d8de', MEDIA);
                if (curTrk.album) {
                    cv.text(fitText(cv, curTrk.album, metaW, alSize, MEDIA), metaX, albumY, alSize, t.dim, MEDIA);
                }

                // what it plays from: the playlist, Liked Songs or the album
                const ctxUri = spotify.contextUri || '';
                let fromKind = '', fromName = '';
                if (/:collection$/.test(ctxUri)) { fromKind = 'LIKED SONGS'; }
                else if (/:playlist:/.test(ctxUri)) {
                    const pl = (spotify.playlists || []).find((p) => p.uri === ctxUri);
                    fromKind = 'PLAYLIST'; fromName = pl ? pl.name : '';
                } else if (/:album:/.test(ctxUri)) { fromKind = 'ALBUM'; fromName = curTrk.album || ''; }
                else if (/:artist:/.test(ctxUri)) { fromKind = 'ARTIST'; }
                if (fromKind) {
                    const fkSize = sz(cv, 9.5), fnSize = sz(cv, 14), fkY = albumY + 22 + fkSize;
                    cv.text('PLAYING FROM ' + fromKind, metaX, fkY, fkSize, t.dim, { font: 'bold', spacing: 1.5 });
                    if (fromName) cv.text(fitText(cv, fromName, metaW, fnSize, MEDIA_BOLD), metaX, fkY + fnSize + 8, fnSize, t.text, MEDIA_BOLD);
                }

                // Progress Bar
                const progX = 54, progY = 360 + npEx, progW = 820, progH = 6;
                const dur = (curTrk && curTrk.durationMs) ? curTrk.durationMs : 1;
                const pFrac = Math.min(1, Math.max(0, spotify.progressMs / dur));
                cv.roundRect(progX, progY, progW, progH, 3, t.tick);
                if (pFrac > 0) {
                    cv.roundRect(progX, progY, Math.round(progW * pFrac), progH, 3, t.accent);
                    cv.circle(progX + Math.round(progW * pFrac), progY + 3, 6, '#ffffff');
                }
                cv.text(fmtTime(spotify.progressMs), progX, progY + 24, 15, t.accent, { font: 'num' });
                cv.text(fmtTime(curTrk.durationMs), progX + progW, progY + 24, 15, t.dim, { align: 'right', font: 'num' });
                // a tap on the bar jumps there; the controller pressed on it jumps 15 s on
                const seekPad = 10;
                cv.target(progX - seekPad, progY - 16, progW + seekPad * 2, 34, (at) => {
                    const to = at && at.w
                        ? (Math.max(0, Math.min(progW, at.x - seekPad)) / progW) * dur
                        : spotify.progressMs + 15000;
                    runBusy('seek', () => spotify.seek(to));
                }, 'np_seek', 6);

                // Transport Controls: shuffle, previous, play, next, repeat centred under the panel,
                // the heart at the right end. Secondary buttons are quiet until they are on.
                // (sized for this display: sz)
                const bh = sz(cv, 43), iconSz = sz(cv, 20);
                const cy = 472 + npEx - bh / 2;
                const midX = 464;
                const btnBg = withAlpha(t.panelEdge, 0.55);
                const toggle = (x, w, on, key, icon, run) => {
                    const y = cy - bh / 2, h = bh;
                    cv.roundRect(x, y, w, h, h / 2, on ? withAlpha(t.accent, 0.18) : btnBg);
                    if (on) cv.strokeRoundRect(x, y, w, h, h / 2, 1.5, withAlpha(t.accent, 0.8));
                    if (isBusy(key)) {
                        drawSpinner(cv, x + w / 2, cy, sz(cv, 8), on ? t.accent : '#aeb4bd');
                    } else {
                        if (on) cv.circle(x + w / 2, y + h - 7, 2.5, t.accent);      // "on" dot, as Spotify marks it
                        icon(x + w / 2, on ? cy - 2 : cy, on ? t.accent : '#aeb4bd');
                    }
                    cv.target(x, y, w, h, () => runBusy(key, run), key, h / 2);
                };

                // 3. Play / Pause: the big round one
                const playR = sz(cv, 30);
                cv.circle(midX, cy, playR, isBusy('transport') ? withAlpha(t.accent, 0.6) : t.accent);
                if (busyOn('transport', 'play')) drawSpinner(cv, midX, cy, sz(cv, 11), '#000000', 4);
                else if (isPlaying) drawPauseIcon(cv, midX, cy, sz(cv, 23), '#000000');
                else drawPlayIcon(cv, midX + 2, cy, sz(cv, 23), '#000000');
                cv.target(midX - playR, cy - playR, playR * 2, playR * 2, () => {
                    runBusy('transport', () => spotify.togglePlay(), 'play');
                }, 'np_play', playR);

                // 2. / 4. Previous, Next: plain white glyphs on a soft round button
                const skipW = sz(cv, 53), skipGap = sz(cv, 16);
                const prevX = midX - playR - skipGap - skipW, nextX = midX + playR + skipGap;
                [[prevX, 'np_prev', 'prev', drawPrevIcon, () => spotify.prevTrack()],
                 [nextX, 'np_next', 'next', drawNextIcon, () => spotify.nextTrack()]].forEach(([x, key, id, icon, run]) => {
                    cv.roundRect(x, cy - bh / 2, skipW, bh, bh / 2, btnBg);
                    if (busyOn('transport', id)) drawSpinner(cv, x + skipW / 2, cy, sz(cv, 8), '#ffffff');
                    else icon(cv, x + skipW / 2, cy, iconSz, isBusy('transport') ? '#6b7280' : '#ffffff');
                    cv.target(x, cy - bh / 2, skipW, bh, () => runBusy('transport', run, id), key, bh / 2);
                });

                // 1. / 5. Shuffle, Repeat
                const togW = sz(cv, 50), togGap = sz(cv, 14);
                toggle(prevX - togGap - togW, togW, !!spotify.shuffle, 'np_shuffle',
                    (x, y, c) => drawShuffleIcon(cv, x, y, iconSz, c), () => spotify.toggleShuffle());
                const repMode = spotify.repeat;
                toggle(nextX + skipW + togGap, togW, !!(repMode && repMode !== 'off'), 'np_repeat',
                    (x, y, c) => drawRepeatIcon(cv, x, y, iconSz, c, repMode), () => spotify.toggleRepeat());

                // 6. Like: at the end of the progress bar's line
                const isLiked = !!spotify.isCurrentLiked;
                const likeW = togW, likeX = 874 - likeW;
                cv.roundRect(likeX, cy - bh / 2, likeW, bh, bh / 2, isLiked ? withAlpha(t.accent, 0.18) : btnBg);
                if (isLiked) cv.strokeRoundRect(likeX, cy - bh / 2, likeW, bh, bh / 2, 1.5, withAlpha(t.accent, 0.8));
                if (isBusy('like')) drawSpinner(cv, likeX + likeW / 2, cy, sz(cv, 8), isLiked ? t.accent : '#aeb4bd');
                else drawHeartIcon(cv, likeX + likeW / 2, cy + 1, iconSz, isLiked ? t.accent : '#aeb4bd', isLiked);
                cv.target(likeX, cy - bh / 2, likeW, bh, () => runBusy('like', () => spotify.toggleLikeCurrent()), 'np_like', bh / 2);
            }

            // Right Pane: Up Next in Queue (w: 656, h: 468)
            let upcoming = (spotify.remoteQueue && spotify.remoteQueue.length) ? spotify.remoteQueue : [];
            if (!upcoming.length && spotify.currentPlaylist && spotify.currentPlaylist.tracks) {
                const trks = spotify.currentPlaylist.tracks;
                const curIdx = trks.findIndex((x) => curTrk && x.id === curTrk.id);
                if (curIdx >= 0 && curIdx < trks.length - 1) {
                    upcoming = trks.slice(curIdx + 1);
                }
            } else if (!upcoming.length && spotify.likedSongs && spotify.likedSongs.length) {
                const curIdx = spotify.likedSongs.findIndex((x) => curTrk && x.id === curTrk.id);
                if (curIdx >= 0 && curIdx < spotify.likedSongs.length - 1) {
                    upcoming = spotify.likedSongs.slice(curIdx + 1);
                }
            }

            G.panel(cv, t, 920, 44, 656, 468, 'Up Next (' + upcoming.length + ')');

            if (!upcoming || upcoming.length === 0) {
                cv.roundRect(938, 120, 620, 180, 10, t.track);
                cv.text('Queue is currently empty.', 1248, 195, 19, t.dim, { align: 'center', font: 'bold' });
                cv.text('Play any track from Playlists or Liked Songs to queue up songs.', 1248, 230, 14, t.dim, { align: 'center' });
                return;
            }

            const m = metrics(cv), qTop = 100, qStep = m.songStep, qH = m.songH;
            const VISIBLE_Q = Math.max(1, Math.floor((498 + npEx - qTop + 6) / qStep));
            queueScroll = Math.max(0, Math.min(queueScroll, Math.max(0, upcoming.length - VISIBLE_Q)));
            listGeo.q = { x0: 920, x1: 1576, rowH: qStep, count: upcoming.length, visible: VISIBLE_Q };
            cv.scroll = true;
            const visibleQ = upcoming.slice(queueScroll, queueScroll + VISIBLE_Q);
            visibleQ.forEach((trk, idx) => {
                const qy = qTop + idx * qStep, qc = qy + qH / 2, base = (s) => qc + s * 0.36;
                cv.roundRect(938, qy, 620, qH, 8, t.track);
                cv.text(String(queueScroll + idx + 1), 938 + sz(cv, 16), base(m.num), m.num, t.dim, { align: 'center', font: 'num' });
                const titleX = 938 + sz(cv, 36), artistX = 1250;
                cv.text(fitText(cv, trk.title, artistX - 14 - titleX, m.title, MEDIA_BOLD), titleX, base(m.title), m.title, t.text, MEDIA_BOLD);
                const timeR = 1540;
                cv.text(fitText(cv, trk.artist, timeR - sz(cv, 44) - artistX, m.meta, MEDIA), artistX, base(m.meta), m.meta, t.dim, MEDIA);
                const startKey = 'q:' + trk.id;
                if (busyOn('start', startKey)) drawSpinner(cv, timeR - 10, qc, sz(cv, 7), t.accent);
                else cv.text(fmtTime(trk.durationMs), timeR, base(m.num), m.num, t.dim, { align: 'right', font: 'num' });

                cv.target(938, qy, 620, qH, () => {
                    // what plays now, from this song on (a song queued by hand: that song alone)
                    const pl = spotify.currentPlaylist;
                    const pIdx = !spotify.contextUri && pl && pl.tracks ? pl.tracks.findIndex((x) => x.id === trk.id) : -1;
                    if (pIdx >= 0) runBusy('start', () => spotify.playTrack(pl, pIdx), startKey);
                    else runBusy('start', () => spotify.playQueued(trk), startKey);
                }, 'q_trk_' + (queueScroll + idx), 8);
            });
        }

        /* ---------- Page 3: Connect & Real Cloud Pairing ---------- */
        function drawConnect(cv, t) {
            // Left: Real Cloud Pairing QR Code or Connected Status
            G.panelExact(cv, t, 24, 44, 580, metrics(cv).panelH, spotify.isAuthenticated() ? 'Spotify Account Status' : 'Scan to Connect Phone');

            const authed = spotify.isAuthenticated();
            if (!authed) showPhoneQr = false;
            if (authed && !showPhoneQr) {
                // Connected Card
                const GREEN = '#1ed760';
                cv.roundRect(48, 98, 532, 284, 14, '#0a1612');
                cv.strokeRoundRect(48, 98, 532, 284, 14, 1.5, withAlpha(GREEN, 0.55));

                // badge: a check in a green disc, a soft ring around it
                const cx = 314, by = 140;
                cv.circle(cx, by, 36, withAlpha(GREEN, 0.12));
                cv.arc(cx, by, 30, 32, 0, 360, withAlpha(GREEN, 0.45));
                cv.circle(cx, by, 25, GREEN);
                cv.polyline([[cx - 11, by + 1], [cx - 4, by + 8], [cx + 11, by - 8]], 4.5, '#04140b');
                cv.circle(cx - 4, by + 8, 2.2, '#04140b');       // round the check's corner

                cv.text('CONNECTED TO SPOTIFY', cx, 202, 20, '#ffffff', { align: 'center', font: 'bold', spacing: 1 });
                const prof = spotify.profile;
                const plan = prof && prof.product ? prof.product.charAt(0).toUpperCase() + prof.product.slice(1) : '';
                cv.text(prof ? fitText(cv, prof.name + (plan ? '  -  ' + plan : ''), 480, 16, MEDIA) : translate('Signed in'), cx, 226, 16, '#cbd5e1', { align: 'center', literal: true });

                // where the music plays: a pill with a live dot, or how to start
                const pillW = 380, pillX = cx - pillW / 2, pillY = 240, pillH = 32;
                if (spotify.activeDevice) {
                    cv.roundRect(pillX, pillY, pillW, pillH, 16, withAlpha(GREEN, 0.14));
                    const label = fitText(cv, translate('Playing on ') + spotify.activeDevice, pillW - 50, 15, MEDIA_BOLD);
                    const lw = cv.textWidth(label, 15, MEDIA_BOLD);
                    const lx = cx - (lw + 18) / 2;
                    cv.circle(lx + 5, pillY + pillH / 2, 5, spotify.isPlaying ? GREEN : withAlpha(GREEN, 0.5));
                    cv.text(label, lx + 18, pillY + 21, 15, GREEN, MEDIA_BOLD);
                } else {
                    cv.roundRect(pillX, pillY, pillW, pillH, 16, withAlpha('#ffffff', 0.06));
                    cv.text(fitText(cv, 'No device playing - open Spotify on your phone', pillW - 24, 14), cx, pillY + 21, 14, '#94a3b8', { align: 'center' });
                }

                // the library at a glance
                const nPl = (spotify.playlists || []).length;
                const nLiked = spotify.likedTotal || (spotify.likedSongs || []).length;
                cv.text(message(nPl === 1 ? '{count} playlist' : '{count} playlists', { count: nPl }) + '   |   ' + message(nLiked === 1 ? '{count} liked song' : '{count} liked songs', { count: nLiked }), cx, 294, 14, '#64748b', { align: 'center' });

                // disconnecting or switching account is the phone's: the car follows it live. The
                // phone page's QR code puts this car on a phone again (a new phone, cleared browser)
                const qbW = 380, qbX = 314 - qbW / 2, qbH = Math.min(56, sz(cv, 36)), qbY = 376 - qbH;
                cv.roundRect(qbX, qbY, qbW, qbH, 10, '#0f1a14');
                cv.strokeRoundRect(qbX, qbY, qbW, qbH, 10, 1, withAlpha(GREEN, 0.6));
                cv.text('SHOW QR FOR THE PHONE PAGE', qbX + qbW / 2, qbY + qbH / 2 + sz(cv, 4), sz(cv, 11), GREEN, { align: 'center', font: 'bold', spacing: 1 });
                cv.target(qbX, qbY, qbW, qbH, () => { showPhoneQr = true; render().catch(() => {}); }, 'btn_phone_qr', 15);
                cv.text('Disconnect or switch account on your phone.', cx, 404, 13, '#64748b', { align: 'center' });
            } else {
                // Real Cloud Pairing QR Code
                const qrx = 224, qry = 100, qrsz = 180;
                const qr = getQrMatrix();
                if (qr) {
                    const modCount = qr.size;
                    const modPx = Math.floor(qrsz / modCount);
                    const actualSz = modPx * modCount;
                    const ox = qrx + Math.floor((qrsz - actualSz) / 2);
                    const oy = qry + Math.floor((qrsz - actualSz) / 2);

                    // White backdrop for clean camera scanning
                    cv.roundRect(ox - 10, oy - 10, actualSz + 20, actualSz + 20, 10, '#ffffff');
                    for (let r = 0; r < modCount; r++) {
                        for (let c = 0; c < modCount; c++) {
                            if (qr.getModule(c, r)) {
                                cv.fillRect(ox + c * modPx, oy + r * modPx, modPx, modPx, '#000000');
                            }
                        }
                    }
                }

                const cx = 314;
                cv.text(authed ? 'Scan to open this car on your phone' : 'Scan with phone to connect Spotify', cx, 320, 17, t.text, { align: 'center', font: 'bold' });
                cv.text('PAIRING CODE: ' + cloudPair.getShortCode(), cx, 344, 14, '#00f0ff', { align: 'center', font: 'bold', spacing: 1 });
                // paired: the phone that scans it may have the app installed; the camera opens the
                // browser, and on iPhone the Home Screen app keeps its own cars
                if (authed) cv.text('Installed the phone app? Scan with its Scan car QR, not the camera.', cx, 364, 12, '#64748b', { align: 'center' });
                else cv.text('https://hexlay.github.io/idrive7-custom-apps/pair.html', cx, 364, 11, '#64748b', { align: 'center' });
                if (authed) {
                    const bbW = 380, bbX = 314 - bbW / 2, bbY = 384, bbH = Math.min(52, sz(cv, 34));
                    cv.roundRect(bbX, bbY, bbW, bbH, 10, '#004e3a');
                    cv.strokeRoundRect(bbX, bbY, bbW, bbH, 10, 1.5, '#1ed760');
                    cv.text('BACK TO THE ACCOUNT', bbX + bbW / 2, bbY + bbH / 2 + sz(cv, 4), sz(cv, 11), '#ffffff', { align: 'center', font: 'bold', spacing: 1 });
                    cv.target(bbX, bbY, bbW, bbH, () => { showPhoneQr = false; render().catch(() => {}); }, 'btn_phone_qr_back', 15);
                }
            }

            // Right: Spotify Connect Target Devices
            G.panelExact(cv, t, 620, 44, 956, metrics(cv).panelH, 'Spotify Connect Devices');
            const devices = spotify.getDevices();

            if (!devices || devices.length === 0) {
                cv.roundRect(644, 100, 908, 230, 14, t.track);
                cv.strokeRoundRect(644, 100, 908, 230, 14, 1, t.panelEdge);

                cv.circle(714, 170, 30, withAlpha(t.accent, 0.22));
                cv.text('!', 714, 180, 26, t.accent, { align: 'center', font: 'bold' });

                cv.text('NO ACTIVE SPOTIFY DEVICES FOUND', 770, 158, 20, t.text, { font: 'bold' });
                cv.text('Open Spotify on your iPhone, Mac, or car to connect playback.', 770, 186, 15, '#cbd5e1');
                cv.text('Spotify Connect routes audio to an active device running Spotify.', 770, 210, 13, t.dim);

                // Refresh Button
                const rfW = 220, rfH = 42, rfX = 770, rfY = 240;
                const devBusy = isBusy('devices');
                cv.roundRect(rfX, rfY, rfW, rfH, 8, withAlpha(t.accent, devBusy ? 0.1 : 0.22));
                cv.strokeRoundRect(rfX, rfY, rfW, rfH, 8, 1.5, withAlpha(t.accent, devBusy ? 0.5 : 1));
                if (devBusy) {
                    drawSpinner(cv, rfX + 44, rfY + rfH / 2, 9, t.accent);
                    cv.text('SEARCHING...', rfX + rfW / 2 + 12, rfY + 26, 14, withAlpha(t.accent, 0.8), { align: 'center', font: 'bold', spacing: 1 });
                } else {
                    cv.text('REFRESH DEVICES', rfX + rfW / 2, rfY + 26, 14, t.accent, { align: 'center', font: 'bold', spacing: 1 });
                }
                cv.target(rfX, rfY, rfW, rfH, () => {
                    runBusy('devices', () => spotify.fetchDevices());
                }, 'btn_refresh_devs', 12);
            } else {
                // as many as the panel holds; the one that plays first
                // (sized for this display: sz)
                const m = metrics(cv), rowH = sz(cv, 54), step = rowH + 10, devTop = 102;
                const DEV_ROWS = Math.max(1, Math.floor((m.listBottom - devTop + 10) / step));
                const nSize = sz(cv, 17), sSize = sz(cv, 12.5), bSize = sz(cv, 11);
                const shown = devices.slice().sort((x, y) => (y.isActive ? 1 : 0) - (x.isActive ? 1 : 0)).slice(0, DEV_ROWS);
                shown.forEach((dev, idx) => {
                    const dy = devTop + idx * step, mid = dy + rowH / 2;
                    const isCur = !!dev.isActive;
                    const moving = busyOn('transfer', dev.id);
                    cv.roundRect(644, dy, 908, rowH, 12, isCur ? withAlpha(t.accent, 0.16) : t.track);
                    if (isCur || moving) cv.strokeRoundRect(644, dy, 908, rowH, 12, 1.5, withAlpha(t.accent, isCur ? 0.8 : 0.4));

                    // the device's kind, in a round tile
                    const iconR = Math.round(rowH * 0.32), iconX = 644 + 18 + iconR;
                    cv.circle(iconX, mid, iconR, isCur ? withAlpha(t.accent, 0.2) : withAlpha('#ffffff', 0.06));
                    drawDeviceIcon(cv, iconX, mid, dev.type, isCur ? t.accent : '#aeb4bd');

                    // the action: where it plays, or "play here"
                    const bw = sz(cv, 104), bh = sz(cv, 30), bx = 644 + 908 - 20 - bw, by = mid - bh / 2;
                    const textX = iconX + iconR + 18;
                    cv.text(fitText(cv, dev.name, bx - 20 - textX, nSize, MEDIA_BOLD), textX, mid - 4, nSize, isCur ? t.text : '#dddddd', MEDIA_BOLD);
                    const vol = typeof dev.volume === 'number' ? '  |  Volume ' + dev.volume + '%' : '';
                    cv.text(fitText(cv, (isCur ? (spotify.isPlaying ? 'Playing now' : 'Paused here') : dev.type) + vol, bx - 20 - textX, sSize), textX, mid + sSize + 4, sSize, isCur ? t.accent : t.dim);
                    const bBase = by + bh / 2 + bSize * 0.36;
                    if (isCur) {
                        cv.roundRect(bx, by, bw, bh, bh / 2, withAlpha(t.accent, 0.22));
                        cv.circle(bx + bh * 0.6, by + bh / 2, 4, t.accent);
                        cv.text('ACTIVE', bx + bw / 2 + 8, bBase, bSize, t.accent, { align: 'center', font: 'bold', spacing: 1 });
                    } else if (moving) {
                        cv.roundRect(bx, by, bw, bh, bh / 2, withAlpha('#ffffff', 0.06));
                        drawSpinner(cv, bx + bw / 2, by + bh / 2, sz(cv, 8), t.accent);
                    } else {
                        const dim = isBusy('transfer');
                        cv.strokeRoundRect(bx, by, bw, bh, bh / 2, 1.5, withAlpha('#ffffff', dim ? 0.15 : 0.45));
                        cv.text('PLAY HERE', bx + bw / 2, bBase, bSize, dim ? '#64748b' : '#ffffff', { align: 'center', font: 'bold', spacing: 1 });
                    }

                    cv.target(644, dy, 908, rowH, () => {
                        if (!isCur) runBusy('transfer', () => spotify.transferToDevice(dev.id), dev.id);
                    }, 'dev_' + idx, 12);
                });
            }

            // Bottom Player Dock
            drawBottomPlayerDock(cv, t);
        }

        /* ---------- Master Render Loop ---------- */
        // What a frame shows, roughly: the loop draws again when it changes, or at least once a second
        // (data that isn't listed here then shows within a second). Taps, scrolling, the album art and
        // the pairing call render() themselves and always draw.
        function frameSig() {
            const trk = spotify.currentTrack, pl = spotify.currentPlaylist, n = spotify.notice;
            return [page, showPhoneQr, selectedPlaylistIdx, playlistScroll, trackScroll, likedScroll, queueScroll,
                settings.get('theme'), settings.get('demo'), spotify.hasInternet, spotify.isAuthenticated(),
                trk ? trk.id : '', spotify.isPlaying, spotify.stalled, spotify.shuffle, spotify.repeat, spotify.isCurrentLiked,
                Math.floor((spotify.progressMs || 0) / 1000), spotify.contextUri, spotify.activeDevice,
                (spotify.playlists || []).length, pl ? pl.id + ':' + ((pl.tracks && pl.tracks.length) || 0) : '',
                (spotify.likedSongs || []).length, spotify.likedTotal, (spotify.remoteQueue || []).length,
                (spotify.devices || []).map((d) => d.id + (d.isActive ? '*' : '')).join(','),
                artManager.hasArt, artManager.currentUrl, n && Date.now() - n.at <= NOTICE_MS ? n.text : ''].join('|');
        }
        let lastSig = '', lastDrawAt = 0;
        /** The loop's frame: drawn while something moves (music, a spinner), on a change, or once a second. */
        function loopFrame() {
            const moving = spotify.isPlaying || Object.keys(busy).some(isBusy) || spotify.isLoadingPlaylists || spotify.isLoadingLiked;
            if (!moving && Date.now() - lastDrawAt < 1000) {
                spotify.tick();                 // the polls go on
                if (frameSig() === lastSig) return Promise.resolve();
            }
            return render();
        }

        async function render() {
            spotify.tick();
            spectrumSeed += 0.08;
            lastSig = frameSig();
            lastDrawAt = Date.now();

            if (spotify.currentTrack && spotify.currentTrack.albumArt) {
                artManager.load(spotify.currentTrack.albumArt);
            } else if (artManager.hasArt) {
                artManager.load(null);           // nothing playing: no leftover album art
            }

            const t = ctx.theme();
            const cv = ctx.canvas(W, H).clear(t.bg);

            const isOnline = settings.get('demo') !== 'on';

            // 1. Connection check: In Online mode, if there is no internet, disable app
            if (isOnline && !spotify.hasInternet) {
                drawNoInternet(cv, t);
                G.frame(cv, t, PAGES, page, [
                    { text: 'SPOTIFY' },
                    { text: 'NO INTERNET (LOCKED)', color: '#e1001a' }
                ]);
                await ui.image('MAIN_GFX', cv);
                return;
            }

            // 2. Authentication check: In Online mode, if unauthenticated, force Connect or Gating
            if (isOnline && !spotify.isAuthenticated()) {
                if (page === 3) {
                    drawConnect(cv, t);
                } else {
                    drawRequireConnect(cv, t);
                }
                G.frame(cv, t, PAGES, page, [
                    { text: 'SPOTIFY' },
                    { text: 'LOGIN REQUIRED', color: '#ffb703' }
                ]);
                await ui.image('MAIN_GFX', cv);
                return;
            }

            // Normal Playback / Browsing screens
            if (page === 0) drawPlaylists(cv, t);
            else if (page === 1) drawLibrary(cv, t);
            else if (page === 2) drawNowPlaying(cv, t);
            else if (page === 3) drawConnect(cv, t);

            // G20 Live Cockpit frame tabs along the top: keep badges compact so tabs & Settings are never crowded out
            G.frame(cv, t, PAGES, page, [
                { text: spotify.activeDevice ? trunc(spotify.activeDevice, 28) : 'SPOTIFY', literal: !!spotify.activeDevice },
                spotify.stalled
                    ? { text: 'NOT RESPONDING', color: '#ffb703' }
                    : { text: spotify.isPlaying ? 'PLAYING' : 'PAUSED', color: spotify.isPlaying ? '#1ed760' : t.dim }
            ]);

            drawNotice(cv, t);
            await ui.image('MAIN_GFX', cv);
        }

        /* What went wrong, for NOTICE_MS over the dock: a tap closes it sooner. */
        const NOTICE_MS = 5000;
        function drawNotice(cv, t) {
            const n = spotify.notice;
            if (!n || Date.now() - n.at > NOTICE_MS) return;
            const size = 16, opts = { font: 'bold' };
            // over the dock's top edge; on Now Playing (no dock, the controls at the bottom) over Up Next
            const onNp = page === 2;
            const cx = onNp ? 1248 : 800, maxW = onNp ? 540 : 1100;
            const text = fitText(cv, n.text, maxW, size, opts);
            const w = cv.textWidth(text, size, opts) + 76, h = 46;
            const x = Math.round(cx - w / 2), y = 446 + (cv.extra || 0) - h - (onNp ? -40 : 12);
            cv.roundRect(x, y, w, h, h / 2, '#2a1d10');
            cv.strokeRoundRect(x, y, w, h, h / 2, 1.5, withAlpha('#ffb703', 0.8));
            cv.circle(x + 26, y + h / 2, 9, '#ffb703');
            cv.text('!', x + 26, y + h / 2 + 5, 14, '#2a1d10', { align: 'center', font: 'bold' });
            cv.text(text, x + 46, y + h / 2 + 6, size, '#ffe2a8', opts);
            cv.target(x, y, w, h, () => { spotify.notice = null; render(); }, 'notice', 23);
            // over the list rows: a tap on it is its own (the first target under a finger wins)
            if (Array.isArray(cv.targets)) cv.targets.unshift(cv.targets.pop());
        }

        /* ---------- HMI Button & Touch Interactions ---------- */
        ui.onClick('BTN_PAGE', () => { page = (page + 1) % PAGES.length; return render(); });
        ctx.onTab((idx) => { page = idx; showPhoneQr = false; return render(); });

        // 30 fps while music plays (spectrum, progress), 10 fps otherwise - and an unchanged frame
        // isn't drawn again (loopFrame); taps redraw at once
        ctx.loop('MAIN', 15, loopFrame, { maxFps: () => (spotify.isPlaying ? 30 : 10) });
        // where the frame goes changed (renderer, layout): draw it again there
        if (ctx.onLayout) ctx.onLayout(() => { render().catch(() => {}); });
        await render();
        log.info('Spotify app ready');
    }
});
