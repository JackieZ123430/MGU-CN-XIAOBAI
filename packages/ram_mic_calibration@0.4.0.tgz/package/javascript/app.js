'use strict';

// 开发维护：抖音 小白科技杂物社 / BiliBili 小白151 / GitHub JackieZ123430
// 基于 cauliflowermossgrape/idrive7-apps 的 OAP 应用框架。

const mgu = require('./kit/mgu');
const { Diag } = require('./kit/diag');
const ram = require('./ram');
const view = require('./view');
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

mgu.run({
    async start(ctx) {
        const { ui, log } = ctx;
        if (ctx.settings.get('layout') !== 'full') ctx.settings.set('layout', 'full');
        const diag = new Diag(ctx.signals, log);
        let speedAt = 0;
        let stopped = false;
        let busy = false;
        let ready = false;
        let beforeStart = false;
        let cancelled = false;
        let status = '可读取 RAM01 的上次校准结果';
        let countdown = 30;
        let countdownState = '请下车并关好车门';

        function show(message) {
            log.info(message);
            status = message;
        }

        function assertParked(screen) {
            if (cancelled) throw new Error('已取消，校准未启动');
            if (!ui.isVisible(screen) || !ui.hasFocus(screen)) throw new Error('校准页面已离开，校准未启动');
            if (!stopped || Date.now() - speedAt > 5000) throw new Error('请停车后再试。车速需要为零');
        }

        function setReady(value) {
            ready = value;
            ui.text('CHECK_READY', ready ? '取消勾选' : '勾选准备');
            ui.enabled('BTN_START', ready);
        }

        setReady(false);

        async function run(operation) {
            busy = true;
            try {
                show(await operation());
            } catch (error) {
                show(error.message || String(error));
            } finally {
                busy = false;
            }
        }

        function read() {
            if (busy) return;
            return run(async () => {
                show('正在识别 RAM 并读取校准状态');
                await ram.identify(diag);
                const result = await ram.readStatus(diag);
                return '上次校准：' + result.text;
            });
        }

        function toggleReady() {
            if (busy) {
                setReady(ready);
                return;
            }
            setReady(!ready);
            show(ready ? '已确认准备条件' : '请先确认准备条件');
        }

        function start() {
            if (busy) return;
            if (!ready) {
                show('请先确认准备条件');
                return;
            }
            cancelled = false;
            try {
                assertParked('MAIN');
                if (!diag.available) throw new Error('车机诊断接口不可用');
            } catch (error) {
                setReady(false);
                show(error.message);
                return;
            }
            setReady(false);
            return run(async () => {
                beforeStart = true;
                try {
                    await ui.enabled('BTN_COUNTDOWN_CANCEL', true);
                    countdown = 30;
                    countdownState = '请下车并关好车门';
                    await ui.open('COUNTDOWN');
                    const openDeadline = Date.now() + 3000;
                    while (!ui.isVisible('COUNTDOWN') && !cancelled && Date.now() < openDeadline) {
                        await delay(100);
                    }
                    assertParked('COUNTDOWN');
                    const deadline = Date.now() + 30000;
                    log.info('RAM native countdown displayed, 30 seconds');
                    while (Date.now() < deadline) {
                        assertParked('COUNTDOWN');
                        countdown = Math.ceil((deadline - Date.now()) / 1000);
                        await delay(250);
                    }
                    assertParked('COUNTDOWN');
                    countdown = 0;
                    countdownState = '正在检查 RAM01';
                    return await ram.calibrate(diag, () => {
                        assertParked('COUNTDOWN');
                        beforeStart = false;
                        ui.enabled('BTN_COUNTDOWN_CANCEL', false);
                        countdownState = '正在校准，等待 RAM01 返回结果';
                    }, show, delay);
                } finally {
                    beforeStart = false;
                    if (ui.isVisible('COUNTDOWN')) await ui.open('MAIN');
                }
            });
        }

        function cancel() {
            setReady(false);
            if (beforeStart) cancelled = true;
            if (!busy) show('已取消，校准未启动');
        }
        ['BTN_READ', 'CHECK_READY', 'BTN_START', 'BTN_COUNTDOWN_CANCEL'].forEach((id) => ctx.hideButton(id));
        ui.onClick('BTN_READ', read);
        ui.onClick('CHECK_READY', toggleReady);
        ui.onClick('BTN_START', start);
        ui.onClick('BTN_COUNTDOWN_CANCEL', cancel);

        const resetConfirmation = (name, on) => {
            if (on) return;
            if (name === 'MAIN' && ready) setReady(false);
            if (name === 'COUNTDOWN' && beforeStart) cancelled = true;
        };
        ui.onVisible(resetConfirmation);
        ui.onFocus(resetConfirmation);

        ctx.loop('MAIN', 2, () => {
            const cv = ctx.canvas(1600, 520);
            view.home(cv, ctx.theme(), ready, status, busy, { read, toggleReady, start });
            return ui.image('MAIN_GFX', cv);
        });
        ctx.loop('COUNTDOWN', 4, () => {
            const cv = ctx.canvas(1600, 520);
            view.countdown(cv, ctx.theme(), countdown, countdownState, beforeStart, cancel);
            return ui.image('COUNTDOWN_GFX', cv);
        });

        ctx.signals.watch('de.bmw.infotainment.vehicle.Vehicle2', '1', {
            statusCarSpeed2(value) {
                // Vehicle2 supplies speed in units of 1/64 km/h; zero is exact.
                stopped = value && value.speedVehicleCentreOfGravity === 0;
                speedAt = Date.now();
                if (!stopped) {
                    if (ready) setReady(false);
                    if (beforeStart) cancelled = true;
                }
            },
        }, log, { pollMs: 2000 }).catch((error) => log.warn('车速信号不可用：' + error));
        diag.init();
    },
});
