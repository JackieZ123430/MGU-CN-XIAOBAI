'use strict';

const WMO = {
    0: '晴',
    1: '大致晴朗',
    2: '局部多云',
    3: '阴',
    45: '雾',
    48: '冻雾',
    51: '轻微毛毛雨',
    53: '中等毛毛雨',
    55: '密集毛毛雨',
    56: '轻微冻毛毛雨',
    57: '密集冻毛毛雨',
    61: '小雨',
    63: '中雨',
    65: '大雨',
    66: '轻微冻雨',
    67: '强冻雨',
    71: '小雪',
    73: '中雪',
    75: '大雪',
    77: '雪粒',
    80: '小阵雨',
    81: '中等阵雨',
    82: '强阵雨',
    85: '小阵雪',
    86: '强阵雪',
    95: '雷雨',
    96: '雷雨伴小冰雹',
    99: '雷雨伴强冰雹'
};

function finite(value) {
    return typeof value === 'number' && isFinite(value);
}

function normalize(raw) {
    if (!raw || !raw.current) throw new Error('天气数据不完整');
    const c = raw.current;
    const h = raw.hourly || {};
    const d = raw.daily || {};
    const hourly = [];
    const times = h.time || [];
    const now = c.time || '';
    for (let i = 0; i < times.length && hourly.length < 24; i++) {
        if (now && times[i] < now) continue;
        hourly.push({
            time: times[i],
            temperature: h.temperature_2m && h.temperature_2m[i],
            precipitationProbability: h.precipitation_probability && h.precipitation_probability[i],
            code: h.weather_code && h.weather_code[i],
            wind: h.wind_speed_10m && h.wind_speed_10m[i]
        });
    }
    const daily = [];
    const days = d.time || [];
    for (let j = 0; j < days.length; j++) {
        daily.push({
            date: days[j],
            code: d.weather_code && d.weather_code[j],
            max: d.temperature_2m_max && d.temperature_2m_max[j],
            min: d.temperature_2m_min && d.temperature_2m_min[j],
            sunrise: d.sunrise && d.sunrise[j],
            sunset: d.sunset && d.sunset[j]
        });
    }
    return {
        fetchedAt: new Date().toISOString(),
        timezone: raw.timezone || '',
        current: {
            time: c.time,
            temperature: c.temperature_2m,
            feelsLike: c.apparent_temperature,
            humidity: c.relative_humidity_2m,
            precipitation: c.precipitation,
            code: c.weather_code,
            description: WMO[c.weather_code] || '当前天气',
            wind: c.wind_speed_10m,
            windDirection: c.wind_direction_10m,
            pressure: c.surface_pressure,
            isDay: c.is_day
        },
        hourly: hourly,
        daily: daily
    };
}

module.exports = { normalize: normalize, description: function (code) { return WMO[code] || '当前天气'; } };
